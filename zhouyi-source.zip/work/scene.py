"""Build the interactive scene: a clean backdrop plate plus one alpha sprite per desk object."""
import cv2, numpy as np, json, time

ref = cv2.imread('ref.png')
H, W = ref.shape[:2]
K = lambda n: cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (n, n))
rng = np.random.default_rng(11)
S = 1.6  # plate / sprite upscale


def rect(x0, y0, x1, y1):
    m = np.zeros((H, W), bool); m[y0:y1, x0:x1] = True; return m


def poly(pts):
    m = np.zeros((H, W), np.uint8); cv2.fillPoly(m, [np.array(pts, np.int32)], 255); return m > 0


# ---------------- object masks ----------------
mk = np.load('masks.npz')
coins = mk['coins'] > 0
burner = mk['burner'] > 0
book = (mk['book'] > 0) & poly([(0, 470), (98, 433), (320, 492), (340, 522), (343, 570), (232, 642), (100, 716), (0, 772)])
book &= ~cv2.dilate(coins.astype(np.uint8), K(3)).astype(bool)
paper = poly([(741, 559), (1206, 642), (1206, 804), (559, 804)])
objects = coins | burner | book | paper

# ---------------- exemplar (Criminisi) inpainting ----------------
def criminisi(img, hole, src_ok, p=4, search=150, block=None):
    ys, xs = np.nonzero(hole)
    y0, y1 = max(0, ys.min() - search - p - 2), min(H, ys.max() + search + p + 3)
    x0, x1 = max(0, xs.min() - search - p - 2), min(W, xs.max() + search + p + 3)
    I = img[y0:y1, x0:x1].copy()
    Hm = hole[y0:y1, x0:x1].copy()
    Bk = np.zeros_like(Hm) if block is None else block[y0:y1, x0:x1].copy()
    k = 2 * p + 1
    S_ = (src_ok[y0:y1, x0:x1] & ~Hm).astype(np.uint8)
    valid = cv2.erode(S_, np.ones((k, k), np.uint8), borderType=cv2.BORDER_CONSTANT, borderValue=0).astype(bool)
    lab = cv2.cvtColor(I, cv2.COLOR_BGR2LAB).astype(np.float32)
    C = (~Hm).astype(np.float32)
    pre = cv2.inpaint(I, Hm.astype(np.uint8) * 255, 5, cv2.INPAINT_TELEA)
    gray = cv2.cvtColor(pre, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255
    h, w = Hm.shape
    one3 = np.ones((3, 3), np.uint8)
    while Hm.any():
        known = (~Hm).astype(np.uint8)
        front = Hm & cv2.dilate(known, one3).astype(bool)
        fy, fx = np.nonzero(front)
        inside = (fy >= p) & (fy < h - p) & (fx >= p) & (fx < w - p)
        fy, fx = fy[inside], fx[inside]
        conf = cv2.boxFilter(C, -1, (k, k), normalize=True, borderType=cv2.BORDER_CONSTANT)[fy, fx]
        mb = cv2.GaussianBlur(Hm.astype(np.float32), (0, 0), 1.5)
        nx = cv2.Sobel(mb, cv2.CV_32F, 1, 0, ksize=3)[fy, fx]; ny = cv2.Sobel(mb, cv2.CV_32F, 0, 1, ksize=3)[fy, fx]
        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)[fy, fx]; gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)[fy, fx]
        D = np.abs(-gy * nx + gx * ny) / (np.hypot(nx, ny) + 1e-6)
        i = np.argmax(conf * (D + 0.02))
        cy, cx = fy[i], fx[i]
        ty0, tx0 = cy - p, cx - p
        tm = ~(Hm | Bk)[ty0:ty0 + k, tx0:tx0 + k]
        tpl = lab[ty0:ty0 + k, tx0:tx0 + k]
        r = search
        while True:
            sy0, sy1 = max(0, cy - r - p), min(h, cy + r + p + 1)
            sx0, sx1 = max(0, cx - r - p), min(w, cx + r + p + 1)
            res = cv2.matchTemplate(lab[sy0:sy1, sx0:sx1], tpl, cv2.TM_SQDIFF, mask=tm.astype(np.uint8))
            vm = valid[sy0 + p:sy0 + p + res.shape[0], sx0 + p:sx0 + p + res.shape[1]]
            res[~vm] = np.inf
            res[~np.isfinite(res)] = np.inf
            if np.isfinite(res).any() or r > max(h, w):
                break
            r *= 2
        ry, rx = np.unravel_index(np.argmin(res), res.shape)
        sy, sx = sy0 + ry, sx0 + rx
        m = Hm[ty0:ty0 + k, tx0:tx0 + k].copy()
        I[ty0:ty0 + k, tx0:tx0 + k][m] = I[sy:sy + k, sx:sx + k][m]
        lab[ty0:ty0 + k, tx0:tx0 + k][m] = lab[sy:sy + k, sx:sx + k][m]
        g = cv2.cvtColor(I[ty0:ty0 + k, tx0:tx0 + k], cv2.COLOR_BGR2GRAY).astype(np.float32) / 255
        gray[ty0:ty0 + k, tx0:tx0 + k][m] = g[m]
        C[ty0:ty0 + k, tx0:tx0 + k][m] = conf[i]
        Hm[ty0:ty0 + k, tx0:tx0 + k][m] = False
    out = img.copy(); out[y0:y1, x0:x1] = I
    return out


def grain(img, mask, strength=0.8):
    f = img.astype(np.float32)
    hp = f - cv2.GaussianBlur(f, (0, 0), 2.0)
    ring = cv2.dilate(mask.astype(np.uint8), np.ones((25, 25), np.uint8)).astype(bool) & ~mask
    std = float(hp[ring].std()) if ring.any() else 4.0
    n = cv2.GaussianBlur(rng.normal(0, 1, f.shape[:2]).astype(np.float32), (0, 0), 0.7)[..., None] * std * strength * 1.6
    f[mask] += n[mask]
    return np.clip(f, 0, 255).astype(np.uint8)


def smooth_fill(img, mask, scale=6):
    m8 = mask.astype(np.uint8) * 255
    sm = cv2.resize(img, (W // scale, H // scale), interpolation=cv2.INTER_AREA)
    mm = cv2.dilate(cv2.resize(m8, (W // scale, H // scale), interpolation=cv2.INTER_NEAREST), np.ones((3, 3), np.uint8))
    up = cv2.resize(cv2.inpaint(sm, mm, 4, cv2.INPAINT_TELEA), (W, H), interpolation=cv2.INTER_CUBIC)
    near = cv2.inpaint(img, m8, 6, cv2.INPAINT_TELEA)  # keeps edge colours right at the boundary
    dist = cv2.distanceTransform(m8, cv2.DIST_L2, 5)
    a = np.clip(dist / 10, 0, 1)[..., None]
    out = img.copy()
    blend = (near * (1 - a) + up * a).astype(np.uint8)
    out[mask] = blend[mask]
    return grain(out, mask)


gray = cv2.cvtColor(ref, cv2.COLOR_BGR2GRAY)
title = np.zeros((H, W), np.uint8)
title[88:197, 408:815] = (gray[88:197, 408:815] < 125) * 255
title = cv2.dilate(title, K(11)) > 0
bgm = cv2.medianBlur(gray, 41).astype(int)
sub = np.zeros((H, W), bool)
sub[193:232, 414:790] = (bgm - gray.astype(int))[193:232, 414:790] > 26
sub = cv2.dilate(sub.astype(np.uint8), K(7)) > 0
seal = rect(812, 112, 852, 170)
yy, xx = np.mgrid[0:H, 0:W]
ABOVE = yy < 350 + (xx - 390) * 0.1425   # painting / wainscot boundary measured on both sides of the old card
holes = {
    'title': title | sub | seal,
    'logo': rect(34, 8, 238, 76),
    'nav': rect(788, 18, 1148, 58),
    'card_hi': rect(390, 256, 818, 522) & ABOVE,
    'card_lo': rect(390, 256, 818, 522) & ~ABOVE,
    'panel': rect(944, 264, 1191, 594),
}
FIX = rect(585, 280, 818, 430) & ABOVE
all_holes = np.zeros((H, W), bool)
for v in holes.values(): all_holes |= v
known = ~all_holes & ~cv2.dilate(objects.astype(np.uint8), K(5)).astype(bool)
srcs = {
    'title': rect(280, 0, 990, 430),
    'logo': rect(52, 0, 275, 260),
    'nav': rect(640, 0, 1206, 130),
    'card_hi': rect(280, 120, 1010, 430) & ABOVE,
    'card_lo': (rect(818, 400, 1010, 530) | rect(300, 350, 390, 470)) & ~ABOVE,
    'panel': rect(800, 90, 1206, 650),
}
plate = ref.copy()
pending = all_holes.copy()
for name in ['title', 'logo', 'nav', 'card_hi', 'card_lo', 'panel']:
    t = time.time()
    pp = {'card_hi': 7, 'card_lo': 6}.get(name, 4)
    pending &= ~holes[name]
    plate = criminisi(plate, holes[name], srcs[name] & known, p=pp, search=220 if pp > 4 else 150, block=pending)
    print(name, 'filled in', round(time.time() - t, 1), 's')
    if name == 'card_hi':
        plate = criminisi(plate, FIX, rect(818, 180, 992, 420) & ABOVE & known, p=6, search=260, block=pending)

# soften blocky seams that exemplar filling leaves inside the large holes (soften blocky)
for name in ['card_hi', 'card_lo', 'panel']:
    reg8 = holes[name].astype(np.uint8)
    a = np.clip(cv2.distanceTransform(reg8, cv2.DIST_L2, 5) / 18.0, 0, 1)[..., None]   # fade the smoothing in over 18px
    soft = cv2.bilateralFilter(cv2.medianBlur(plate, 5), 7, 30, 5).astype(np.float32)
    tmp = (plate.astype(np.float32) * (1 - a) + soft * a).astype(np.uint8)
    plate = grain(tmp, a[..., 0] > 0.5, 0.45)

# table under each object (only its rim ever shows when the object lifts)
under = cv2.dilate(objects.astype(np.uint8), K(7)).astype(bool)
plate = smooth_fill(plate, under)
cv2.imwrite('scene_plate_1x.png', plate)


def upscale(img, s=S):
    up = cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_LANCZOS4)
    bl = cv2.GaussianBlur(up, (0, 0), 1.2)
    return cv2.addWeighted(up, 1.45, bl, -0.45, 0)


cv2.imwrite('scene_plate.jpg', upscale(plate), [cv2.IMWRITE_JPEG_QUALITY, 84, cv2.IMWRITE_JPEG_PROGRESSIVE, 1])

# ---------------- paper: wipe the garbled hexagram so the page can ink its own ----------------
pg = ref.copy()
gi = gray.astype(int); bgp = cv2.medianBlur(gray, 31).astype(int)
strokes = np.zeros((H, W), np.uint8)
strokes[612:775, 732:968] = ((bgp - gi)[612:775, 732:968] > 12) * 255
strokes[600:662, 938:985] = 0  # keep the brush tip
strokes = cv2.dilate(strokes, K(13))
pg = cv2.inpaint(pg, strokes, 11, cv2.INPAINT_TELEA)
pg = grain(pg, strokes > 0, 0.6)

# ---------------- sprites ----------------
geo = {'stage': [W, H], 'objects': {}}
for name, m, srcimg in [('coins', coins, ref), ('book', book, ref), ('burner', burner, ref), ('paper', paper, pg)]:
    m8 = m.astype(np.uint8) * 255
    x, y, w, h = cv2.boundingRect(m8)
    x0, y0, x1, y1 = max(0, x - 3), max(0, y - 3), min(W, x + w + 3), min(H, y + h + 3)
    rgb = upscale(srcimg[y0:y1, x0:x1])
    a = cv2.GaussianBlur(m8[y0:y1, x0:x1].astype(np.float32), (0, 0), 0.6)
    a = cv2.resize(a, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_LINEAR)
    rgba = np.dstack([rgb, np.clip(a, 0, 255).astype(np.uint8)])
    cv2.imwrite(f'sp_{name}.webp', rgba, [cv2.IMWRITE_WEBP_QUALITY, 90])
    cnts, _ = cv2.findContours(m8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    c = max(cnts, key=cv2.contourArea)
    ap = cv2.approxPolyDP(c, 1.6, True)[:, 0, :]
    bw, bh = x1 - x0, y1 - y0
    geo['objects'][name] = {
        'box': [round(x0 / W * 100, 3), round(y0 / H * 100, 3), round(bw / W * 100, 3), round(bh / H * 100, 3)],
        'poly': ' '.join(f'{(px - x0) / bw * 100:.1f}% {(py - y0) / bh * 100:.1f}%' for px, py in ap),
        'center': [round((x + w / 2) / W * 100, 2), round((y + h / 2) / H * 100, 2)],
    }
json.dump(geo, open('scene_geo.json', 'w'), ensure_ascii=False, indent=1)

import os
for f in ['scene_plate.jpg'] + [f'sp_{n}.webp' for n in geo['objects']]:
    print(f, os.path.getsize(f) // 1024, 'KB')
print({k: len(v['poly'].split(',')) for k, v in geo['objects'].items()})
