import cv2, numpy as np

ref = cv2.imread('ref.png')
rng = np.random.default_rng(7)


def rect_mask(shape, rects):
    m = np.zeros(shape[:2], np.uint8)
    for x0, y0, x1, y1 in rects:
        m[y0:y1, x0:x1] = 255
    return m


def stroke_mask(img, rect, dark=True, thr=28, dil=3, k=41):
    """Pixels that differ from the local background (median) inside rect."""
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    bg = cv2.medianBlur(g, k).astype(int)
    d = (bg - g.astype(int)) if dark else (g.astype(int) - bg)
    m = np.zeros(g.shape, np.uint8)
    x0, y0, x1, y1 = rect
    sub = (d[y0:y1, x0:x1] > thr).astype(np.uint8) * 255
    m[y0:y1, x0:x1] = sub
    if dil:
        m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * dil + 1, 2 * dil + 1)))
    return m


def grain(img, mask, strength=0.9):
    """Add noise matching the high-frequency texture found around the mask."""
    f = img.astype(np.float32)
    hp = f - cv2.GaussianBlur(f, (0, 0), 2.0)
    ring = cv2.dilate(mask, np.ones((25, 25), np.uint8)) & ~mask
    std = hp[ring > 0].std(0) if ring.any() else np.array([4, 4, 4])
    n = rng.normal(0, 1, f.shape[:2]).astype(np.float32)
    n = cv2.GaussianBlur(n, (0, 0), 0.7)[..., None] * float(np.mean(std)) * strength * 1.6
    out = f.copy()
    out[mask > 0] += n[mask > 0]
    return np.clip(out, 0, 255).astype(np.uint8)


def big_fill(img, mask, scale=8):
    """Low-frequency fill for large holes: inpaint small, upsample, feather, add grain."""
    h, w = mask.shape
    sm = cv2.resize(img, (w // scale, h // scale), interpolation=cv2.INTER_AREA)
    mm = cv2.resize(mask, (w // scale, h // scale), interpolation=cv2.INTER_NEAREST)
    mm = cv2.dilate(mm, np.ones((3, 3), np.uint8))
    sm = cv2.inpaint(sm, mm, 4, cv2.INPAINT_TELEA)
    up = cv2.resize(sm, (w, h), interpolation=cv2.INTER_CUBIC)
    soft = cv2.GaussianBlur(cv2.dilate(mask, np.ones((7, 7), np.uint8)).astype(np.float32) / 255, (0, 0), 3)[..., None]
    out = (img.astype(np.float32) * (1 - soft) + up.astype(np.float32) * soft).astype(np.uint8)
    return grain(out, mask)


def small_fill(img, mask, r=6):
    out = cv2.inpaint(img, mask, r, cv2.INPAINT_TELEA)
    return grain(out, mask, 0.8)


def upscale(img, s):
    up = cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_LANCZOS4)
    bl = cv2.GaussianBlur(up, (0, 0), 1.2)
    return cv2.addWeighted(up, 1.45, bl, -0.45, 0)


# ---------- background plate: remove every piece of UI ----------
plate = ref.copy()
big = rect_mask(ref.shape, [(34, 8, 238, 76),      # logo
                            (788, 18, 1148, 58),    # nav
                            (392, 258, 815, 518),   # card
                            (946, 266, 1189, 591)]) # side panel
plate = big_fill(plate, big)

gray = cv2.cvtColor(ref, cv2.COLOR_BGR2GRAY)
title = np.zeros(gray.shape, np.uint8)
title[88:197, 408:815] = (gray[88:197, 408:815] < 125).astype(np.uint8) * 255
title = cv2.dilate(title, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11)))
sub = stroke_mask(ref, (414, 193, 790, 232), thr=26, dil=3)
b, g_, r = [ref[..., i].astype(int) for i in range(3)]
seal = np.zeros(title.shape, np.uint8)
seal[112:170, 812:852] = 255  # whole seal box
strokes = title | sub | seal
plate = small_fill(plate, strokes, 9)
cv2.imwrite('plate_1x.png', plate)
cv2.imwrite('plate.jpg', upscale(plate, 1.6), [cv2.IMWRITE_JPEG_QUALITY, 84, cv2.IMWRITE_JPEG_PROGRESSIVE, 1])

# ---------- paper card texture (text + button removed) ----------
card = ref[264:512, 397:809].copy()
cm_text = np.zeros(card.shape[:2], np.uint8)
for rr in [(50, 30, 362, 106), (50, 190, 362, 222)]:
    cm_text |= stroke_mask(card, rr, thr=24, dil=2, k=31)
card = small_fill(card, cm_text, 5)
cm_btn = rect_mask(card.shape, [(66, 124, 347, 183)])
card = big_fill(card, cm_btn, scale=6)
cv2.imwrite('card_1x.png', card)
cv2.imwrite('card.png', upscale(card, 2))

# ---------- button texture (label + arrow removed) ----------
btn = ref[391:444, 466:741].copy()
bm = stroke_mask(btn, (26, 8, 249, 45), dark=False, thr=22, dil=2, k=21)
btn = cv2.inpaint(btn, bm, 4, cv2.INPAINT_TELEA)
btn = grain(btn, bm, 0.25)
cv2.imwrite('btn_1x.png', btn)
cv2.imwrite('btn.png', upscale(btn, 2))

for n in ['plate.jpg', 'card.png', 'btn.png']:
    import os; print(n, os.path.getsize(n) // 1024, 'KB', cv2.imread(n).shape)
