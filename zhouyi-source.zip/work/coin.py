"""Procedural bronze 開元通寶 coin faces (front/back) with height-map lighting, patina and wear."""
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
S=640; c=S/2; R=S*.49
y,x=np.mgrid[0:S,0:S].astype(np.float32); r=np.hypot(x-c,y-c)
rng=np.random.default_rng(7)
def noise(scale,seed):
    g=cv2.GaussianBlur(np.random.default_rng(seed).random((S,S)).astype(np.float32),(0,0),scale*.6)
    g-=g.min();return g/g.max()
fbm=lambda seed:sum(noise(s,seed+i)*w for i,(s,w) in enumerate([(64,.5),(24,.25),(9,.15),(3,.1)]))
sq=lambda h:np.maximum(abs(x-c),abs(y-c))<h
def smooth(m,k):return cv2.GaussianBlur(m.astype(np.float32),(0,0),k)

def face(text):
    H=np.zeros((S,S),np.float32)
    disc=(r<R).astype(np.float32)
    H+=.32*disc*(1-(r/R)**2*.15)                               # field, slight dome
    rim=((r>R*.86)&(r<R)).astype(np.float32); H=np.maximum(H,rim*(1-((r-R*.93)/(R*.07))**2*.25))
    hole=S*.118; H=np.maximum(H,(sq(hole+S*.028)&~sq(hole)).astype(np.float32)*.95)
    if text:
        im=Image.new('L',(S,S),0);d=ImageDraw.Draw(im)
        f=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc',int(S*.2),index=2)  # TC
        for ch,(dx,dy) in zip(text,[(0,-.3),(0,.3),(.3,0),(-.3,0)]):
            d.text((c+dx*S,c+dy*S),ch,font=f,fill=255,anchor='mm')
        t=np.asarray(im,np.float32)/255; t=smooth(t,1.2)
        H=np.maximum(H,t*(.78+.22*fbm(3)))
    else:  # crescent on the back, typical of Kaiyuan coins
        m=np.zeros((S,S),np.uint8); cv2.ellipse(m,(int(c),int(c+S*.25)),(int(S*.1),int(S*.05)),0,200,340,255,int(S*.022))
        H=np.maximum(H,smooth(m/255.,1.5)*.7)
    H-=fbm(11)*.06+noise(1.5,41)*.05   # casting roughness and pits
    H=smooth(H,1.1)
    alpha=np.clip((R-r)+.5,0,1)*np.clip(np.maximum(abs(x-c),abs(y-c))-hole+.5,0,1)
    # normals and light
    gx=cv2.Sobel(H,cv2.CV_32F,1,0,ksize=3);gy=cv2.Sobel(H,cv2.CV_32F,0,1,ksize=3)
    n=np.dstack([-gx*14,-gy*14,np.ones_like(H)]);n/=np.linalg.norm(n,axis=2,keepdims=True)
    L=np.array([-.5,-.6,.62]);L/=np.linalg.norm(L)
    diff=np.clip((n*L).sum(2),0,1)
    hv=L+np.array([0,0,1]);hv/=np.linalg.norm(hv)
    spec=np.clip((n*hv).sum(2),0,1)**36*.7
    cav=np.clip(smooth(H,6)-H,0,1)*8                       # crevices: patina and grime collect here
    high=np.clip((H-.6)*3,0,1)*np.clip(fbm(31)*2-.45,0,1)                              # raised, handled areas: worn bright
    base=np.array([.36,.24,.12])                            # dark bronze (RGB)
    bright=np.array([.86,.62,.34])                          # polished copper-gold
    green=np.array([.28,.44,.34])                           # verdigris
    pat=np.clip(fbm(23)*2.4-.85,0,1)*(1-high*.8)
    col=base*(1+.5*fbm(5)[...,None])
    col=col*(1-pat[...,None]*.7)+green*pat[...,None]*.7
    col=col*(1-np.clip(cav,0,1)[...,None]*.55)+green*.4*np.clip(cav-.3,0,1)[...,None]*.5
    col=col*(1-high[...,None])+bright*high[...,None]*(.75+.25*fbm(9)[...,None])
    shade=.32+.95*diff
    out=col*shade[...,None]+spec[...,None]*np.array([1,.86,.62])*(.25+.75*high[...,None])
    # darken the outer edge of the rim (bevel)
    out*=np.clip(1-((r-R*.975)/(R*.025)),.45,1)[...,None]
    rgba=np.dstack([np.clip(out,0,1),alpha])
    return (rgba*255).astype(np.uint8)
for name,txt in [('front','開元通寶'),('back','')]:
    a=face(txt); img=Image.fromarray(a,'RGBA').resize((512,512),Image.LANCZOS)
    img.save(f'/home/claude/site/work/coin_{name}.webp',quality=86,method=6); img.save(f'/home/claude/site/work/coin_{name}.png')
import os;print({f:os.path.getsize('/home/claude/site/work/'+f) for f in ['coin_front.webp','coin_back.webp']})
