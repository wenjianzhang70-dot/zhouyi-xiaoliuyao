"""Cut each desk object out of the reference image (1206x804) as a binary mask."""
import cv2, numpy as np

ref = cv2.imread('ref.png')
H, W = ref.shape[:2]
hsv = cv2.cvtColor(ref, cv2.COLOR_BGR2HSV)
h, s, v = [hsv[..., i].astype(int) for i in range(3)]
K = lambda n: cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (n, n))


def grab(rect, fg_hint=None, bg_hint=None, iters=6):
    m = np.full((H, W), cv2.GC_BGD, np.uint8)
    x0, y0, x1, y1 = rect
    m[y0:y1, x0:x1] = cv2.GC_PR_FGD if fg_hint is None else cv2.GC_PR_BGD
    if fg_hint is not None:
        m[(fg_hint > 0) & (m != cv2.GC_BGD)] = cv2.GC_PR_FGD
    if bg_hint is not None:
        m[bg_hint > 0] = cv2.GC_BGD
    bgd, fgd = np.zeros((1, 65)), np.zeros((1, 65))
    cv2.grabCut(ref, m, None, bgd, fgd, iters, cv2.GC_INIT_WITH_MASK)
    return np.where((m == cv2.GC_FGD) | (m == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)


def ell(cx, cy, ax, ay, ang=0):
    m = np.zeros((H, W), np.uint8)
    cv2.ellipse(m, ((cx, cy), (2 * ax, 2 * ay), ang), 255, -1)
    return m


def largest(m, n=1):
    k, lab, st, _ = cv2.connectedComponentsWithStats(m)
    keep = np.argsort(st[1:, cv2.CC_STAT_AREA])[::-1][:n] + 1
    return np.isin(lab, keep).astype(np.uint8) * 255


def fill_holes(m):
    f = m.copy()
    ff = np.zeros((H + 2, W + 2), np.uint8)
    cv2.floodFill(f, ff, (0, 0), 255)
    return m | cv2.bitwise_not(f)


# ---- coins + cord + tassel ----
coins = ell(408.5, 686, 52, 36.5) | ell(495.5, 688.5, 47, 32.5) | ell(525.5, 651.5, 55, 31.5)
red = (((h < 8) | (h > 168)) & (s > 110) & (v > 30)).astype(np.uint8) * 255
red[:, :90] = 0; red[:575] = 0; red[:, 600:] = 0
red = cv2.morphologyEx(red, cv2.MORPH_CLOSE, K(5))
hint = coins | red
cord = grab((88, 572, 600, 804), fg_hint=cv2.dilate(hint, K(3)))
cord = largest(cv2.morphologyEx(cord & cv2.dilate(hint, K(15)), cv2.MORPH_OPEN, K(3)))
m_coins = fill_holes(cord | coins)

# ---- book stack ----
book = grab((0, 425, 345, 800))
m_book = fill_holes(largest(cv2.morphologyEx(book, cv2.MORPH_OPEN, K(5))))
m_book &= ~cv2.dilate(m_coins, K(3))

# ---- incense burner ----
burn = grab((48, 312, 252, 465))
m_burner = fill_holes(largest(cv2.morphologyEx(burn, cv2.MORPH_OPEN, K(5))))
m_burner &= ~m_book

# ---- paper + brush ----
pv = ((v > 105) & (s < 150)).astype(np.uint8) * 255
pv[:548] = 0; pv[:, :548] = 0
pv = largest(cv2.morphologyEx(pv, cv2.MORPH_OPEN, K(5)))
brush = ((v < 70)).astype(np.uint8) * 255
bz = np.zeros_like(brush); cv2.fillConvexPoly(bz, np.array([[945, 612], [975, 612], [1206, 790], [1206, 804], [1150, 804]]), 255)
brush &= bz
brush = cv2.morphologyEx(brush, cv2.MORPH_CLOSE, K(7))
m_paper = fill_holes(cv2.morphologyEx(pv | brush, cv2.MORPH_CLOSE, K(9)))
m_paper &= ~cv2.dilate(m_coins, K(3))

np.savez_compressed('masks.npz', coins=m_coins, book=m_book, burner=m_burner, paper=m_paper)

# overlay preview
ov = ref.copy()
for m, c in [(m_coins, (0, 200, 255)), (m_book, (255, 120, 0)), (m_burner, (0, 255, 0)), (m_paper, (255, 0, 255))]:
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    cv2.drawContours(ov, cnts, -1, c, 2)
cv2.imwrite('mask_overlay.png', ov)
for n, m in [('coins', m_coins), ('book', m_book), ('burner', m_burner), ('paper', m_paper)]:
    x, y, w, hh = cv2.boundingRect(m); print(n, (x, y, x + w, y + hh), int(m.sum() / 255))
