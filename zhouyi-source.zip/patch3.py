import re
s = open('src2.html', encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:60], s.count(old))
    s = s.replace(old, new)

# ---------- head ----------
rep('<title>周毅小六爻</title>', '''<title>周毅小六爻 · 铜钱摇卦与小六壬</title>
<meta name="description" content="A quiet study for classical Chinese divination: cast three coins for a Book of Changes hexagram, count an hourly Xiao Liu Ren reading, and browse all 64 hexagrams. 周毅小六爻。">
<meta name="theme-color" content="#130e0a">
<meta property="og:type" content="website"><meta property="og:title" content="Zhou Yi Xiao Liu Yao · 周毅小六爻">
<meta property="og:description" content="Cast coins, count the hours, read the Book of Changes. A quiet study of classical Chinese divination.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='10' fill='%23130e0a'/%3E%3Ccircle cx='32' cy='32' r='22' fill='none' stroke='%23c9a86a' stroke-width='3'/%3E%3Crect x='26' y='26' width='12' height='12' fill='none' stroke='%23c9a86a' stroke-width='3'/%3E%3C/svg%3E">''')
rep('family=Noto+Serif+SC:wght@400;600;700&display=swap', 'family=Noto+Serif+SC:wght@400;600;700&family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&display=swap')

# ---------- css ----------
rep('</style>', '''
/* ---------- texture and atmosphere ---------- */
body{animation:dawn 1.6s ease-out both}
@keyframes dawn{from{filter:brightness(0)}}
.glow{position:absolute;inset:0;pointer-events:none;mix-blend-mode:soft-light;z-index:3;
  background:radial-gradient(38% 34% at 30% 62%,rgba(255,190,110,.55),transparent 70%),radial-gradient(30% 26% at 78% 70%,rgba(255,200,130,.4),transparent 70%);animation:breathe 7s ease-in-out infinite}
@keyframes breathe{0%,100%{opacity:.55}35%{opacity:.85}60%{opacity:.62}80%{opacity:.8}}
#dust{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:8}
.grain{position:fixed;inset:0;pointer-events:none;z-index:9;opacity:.2;mix-blend-mode:soft-light;
  background:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 .6  0 0 0 0 .5  0 0 0 0 .4  0 0 0 1.1 -.2'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")}
.hero-title{animation:bloom 2.2s .5s cubic-bezier(.2,.7,.2,1) both}
@keyframes bloom{from{opacity:0;filter:blur(7px);letter-spacing:.2em}}
.seal{animation:stamp .5s 2.2s cubic-bezier(.3,1.4,.5,1) both}
@keyframes stamp{from{opacity:0;transform:rotate(-2deg) scale(1.9)}}
.hero-sub,.inscribe{animation:fadein 1.6s 1.6s both}
.chop{position:absolute;right:6px;top:4px;width:44px;height:44px;background:var(--cinnabar);color:#f3e2cf;border-radius:3px;display:flex;align-items:center;justify-content:center;
  font:400 30px/1 var(--f-brush);transform:rotate(-4deg);opacity:.9;box-shadow:inset 0 0 0 2px rgba(243,226,207,.35);animation:stamp .5s .35s cubic-bezier(.3,1.4,.5,1) both}
.sec-head{position:relative;padding:0 30px}
@media (max-width:640px){.chop{right:auto;left:0;width:34px;height:34px;font-size:23px}body.en .hero-sub{letter-spacing:.1em}}

/* ---------- English ---------- */
body.en{--f-serif:'EB Garamond','Noto Serif SC',Georgia,serif}
body.en .sheet p,body.en .sheet li{font-size:17.5px;line-height:1.7}
body.en .note{font-size:15px!important}body.en .small-print{font-size:14px!important;letter-spacing:.01em}
body.en .sec-head h2{letter-spacing:.04em;font-weight:600}
body.en .sec-head .tag,body.en .label{letter-spacing:.06em;font-style:italic;font-size:16px}
body.en .btn-ink,body.en .btn-line{letter-spacing:.06em;font-size:17px}
body.en .reading .k{display:block;min-width:0;letter-spacing:.04em;font-size:14px;text-transform:uppercase;margin-bottom:1px}
body.en .xres h3{letter-spacing:.06em}
body.en .brand-text small{letter-spacing:.08em;font-style:italic}
body.en .hero-sub{letter-spacing:.2em;font-size:min(1.45cqw,calc(var(--vw,9999px)*.034));text-transform:uppercase}
body.en .hero-sub span{margin-right:-.2em}
body.en .inscribe{font:italic 400 1.25cqw/1 var(--f-serif);letter-spacing:.14em;margin-right:0}
body.en .slip{width:auto;padding:.5cqw .7cqw .45cqw;translate:-50% 0;font:500 1.12cqw/1.1 var(--f-serif);letter-spacing:.03em;white-space:nowrap}
body.en .slip[data-for=o-painting]{translate:8% 0}
body.en .gua-grid span{font-size:14px;letter-spacing:0}
body.en .cell b{font-size:17px;letter-spacing:.02em}body.en .cell small{letter-spacing:.02em;font-size:13px}
body.en .pan{letter-spacing:.04em}
body.en .lines{font-size:15px}
.snd.lang{right:calc(max(16px,env(safe-area-inset-right,0px),3.4vw) + 50px);font:400 14px/1 var(--f-serif);letter-spacing:.02em}
.sel{user-select:all}.contact-row a{color:var(--cinnabar)}
</style>''')

# ---------- static markup ----------
rep('<canvas id="smoke" aria-hidden="true"></canvas>', '<div class="glow" aria-hidden="true"></div>\n    <canvas id="smoke" aria-hidden="true"></canvas>\n    <canvas id="dust" aria-hidden="true"></canvas>')
for hid, (z, e) in {'o-coins':('铜钱：铜钱摇卦','x'),'o-burner':('香炉：时辰起课','x'),'o-book':('《周易》古书：卦例解析','x'),'o-paper':('卦纸与毛笔：周毅解卦','x'),'o-painting':('山水画：了解小六爻','x')}.items():
    rep(f'<button class="hit" aria-label="{z}"', f'<button class="hit" data-lbl="{hid}" aria-label="{z}"')
rep('<p class="hero-sub"><span>传承古法 · 精准断卦</span></p>', '<p class="hero-sub"><span data-zh="传承古法 · 以卦自省" data-en="Classical Chinese divination">传承古法 · 以卦自省</span></p>')
rep('<p class="inscribe">点选案上之物</p>', '<p class="inscribe" data-zh="点选案上之物" data-en="Choose an object on the desk">点选案上之物</p>')
for zh, en, k in [('铜<br>钱<br>摇<br>卦','Cast the Coins','cast'),('时<br>辰<br>起<br>课','Hourly Reading','xlr'),('卦<br>例<br>解<br>析','The 64 Hexagrams','gua'),('周<br>毅<br>解<br>卦','Ask Zhou Yi','contact'),('了<br>解<br>小<br>六<br>爻','About','about')]:
    rep(f'<span>{zh}</span></button>', f'<span data-zh="{zh}" data-en="{en}">{zh}</span></button>')
rep('<small>一卦一问 · 指引人生</small>', '<small data-zh="一卦一问 · 观己省身" data-en="One question · one hexagram">一卦一问 · 观己省身</small>')
rep('<button class="snd" id="snd" aria-pressed="true" aria-label="声音开关"><span>声</span></button>',
    '<button class="snd lang" id="lang" aria-label="Language"></button>\n<button class="snd" id="snd" aria-pressed="true" aria-label="声音 / Sound"><span>声</span></button>\n<div class="grain" aria-hidden="true"></div>\n<noscript><p style="position:fixed;inset:40% 10% auto;text-align:center;color:#e4d9c1">This page needs JavaScript. 请开启 JavaScript。</p></noscript>')
rep('<p class="pan gone" id="pan">← 左右滑动，看看案上之物 →</p>', '<p class="pan gone" id="pan" data-zh="← 左右滑动，看看案上之物 →" data-en="← Swipe to look around the desk →">← 左右滑动，看看案上之物 →</p>')
rep('aria-label="关闭">×', 'aria-label="关闭 / Close">×')

# ---------- js: language core ----------
rep("const store={get(k)", "let LANG;\nconst T=(zh,en)=>LANG==='en'?en:zh;\nconst store={get(k)")
rep("let SW=1206;", "let SW=1206;")  # sanity anchor

JS_NEW = r'''
/* ---------- English data (our own paraphrase of each hexagram; classical text stays in Chinese) ---------- */
const EN_NAT={乾:'Heaven',兑:'Lake',离:'Fire',震:'Thunder',巽:'Wind',坎:'Water',艮:'Mountain',坤:'Earth'};
const EN_G=[
['Qián','The Creative','Strong, forward-moving energy. Take the initiative and keep to the right path, without arrogance.'],
['Kūn','The Receptive','Yield and support. Follow a suitable guide and carry things with patience.'],
['Zhūn','Difficulty at the Beginning','Beginnings are messy. Lay foundations and find helpers first.'],
['Méng','Youthful Folly','Things are unclear. Stay humble; ask once and listen well.'],
['Xū','Waiting','The moment has not come. Wait patiently, keep faith, conserve strength.'],
['Sòng','Conflict','Signs of dispute. Stop in time and seek mediation rather than fighting to the end.'],
['Shī','The Army','Organization and discipline are needed. The right people and a clear purpose bring stability.'],
['Bǐ','Holding Together','Closeness and mutual support. Committing early beats waiting on the fence.'],
['Xiǎo Chù','Small Accumulating','Little is stored so far, like clouds without rain. Build up first; do not rush.'],
['Lǚ','Treading','Like treading on a tiger’s tail: be careful and courteous, and follow the rules.'],
['Tài','Peace','Above and below are connected and things flow. Make good use of the moment.'],
['Pǐ','Standstill','Communication is blocked. Draw in, keep discipline, wait for a turn.'],
['Tóng Rén','Fellowship','Being of one mind with others. Cooperate openly and gather people with fairness.'],
['Dà Yǒu','Great Possession','Abundance. Stay modest, do good and use what you have well.'],
['Qiān','Modesty','Humility and follow-through take you farther than display.'],
['Yù','Enthusiasm','Good spirits and people responding. Plan ahead; do not sink into comfort.'],
['Suí','Following','Adapt to change and follow what is good. Know when to rest and adjust.'],
['Gǔ','Work on the Decayed','Old problems have piled up, so it is time to repair. Think carefully before and after.'],
['Lín','Approach','An opportunity draws near. Meet it actively, and watch for change after the peak.'],
['Guān','Contemplation','Observe first, then act. Lead by example so that others trust you.'],
['Shì Kè','Biting Through','An obstacle lies in the way. Clear it with firm, fair rules.'],
['Bì','Grace','Beauty and form matter, but do not let polish replace substance.'],
['Bō','Splitting Apart','Things are eroding. Hold still, protect what you have and do not force action.'],
['Fù','Return','A turning point, with light returning. Go back to basics and recover step by step.'],
['Wú Wàng','Innocence','Act sincerely, without scheming. The unexpected may come; stay honest.'],
['Dà Chù','Great Accumulating','Store up strength and learning. Stay steady and invest in growth.'],
['Yí','Nourishment','Mind what you take in and what you say. Look after body and mind.'],
['Dà Guò','Preponderance of the Great','Overloaded, like a bending beam. Bold adjustment is needed, but do not carry it alone.'],
['Kǎn','The Abysmal (Water)','Hazards come one after another. Stay sincere and steady and cross them one at a time.'],
['Lí','The Clinging (Fire)','Brightness depends on what it clings to. Stay clear-minded and choose your company well.'],
['Xián','Influence','Mutual attraction and response. Approach with sincerity and an open mind.'],
['Héng','Duration','Persistence. Keep a steady course and consistent principles.'],
['Dùn','Retreat','A strategic step back. Withdraw to keep your strength.'],
['Dà Zhuàng','Great Power','Strong momentum. Stay upright and do not overreach.'],
['Jìn','Progress','Rising like the sun. Advance, be recognized, and stay modest.'],
['Míng Yí','Darkening of the Light','In hard times, keep your light quiet. Hold inner integrity and avoid display.'],
['Jiā Rén','The Family','Order begins at home: clear roles, honest words, steady conduct.'],
['Kuí','Opposition','Differences between people. Look for common ground in small things; do not force the big ones.'],
['Jiǎn','Obstruction','The path is blocked. Pause, reflect and ask for help.'],
['Xiè','Deliverance','Tension is easing. Be forgiving and act early.'],
['Sǔn','Decrease','Reduce to rebalance. Restrain desire; sincerity is enough.'],
['Yì','Increase','A time of benefit. Learn from what is good and correct your faults.'],
['Guài','Breakthrough','Decide decisively and state your position openly, but avoid head-on clashes.'],
['Gòu','Coming to Meet','An unexpected encounter. Take care with people or matters that come on too strong.'],
['Cuì','Gathering Together','People gather and need a centre and an order. Guard against surprises.'],
['Shēng','Pushing Upward','A steady rise. Small steps add up.'],
['Kùn','Oppression','Hemmed in. Hold to your aims, speak less and do more.'],
['Jǐng','The Well','The foundation does not change. Keep giving, and finish what you begin.'],
['Gé','Revolution','A time of change. Trust is won when the time is ripe.'],
['Dǐng','The Cauldron','Establish a new order. Be steady and upright, and gather capable people.'],
['Zhèn','The Arousing (Thunder)','A sudden shock. Stay calm and use it for self-examination.'],
['Gèn','Keeping Still (Mountain)','Stop in time and keep to your place.'],
['Jiàn','Development','Gradual progress. Step by step brings results.'],
['Guī Mèi','The Marrying Maiden','Standing is not yet clear. Do not force it; think long-term.'],
['Fēng','Abundance','A time of fullness. Seize the present, and remember that peaks change.'],
['Lǚ','The Wanderer','Away from home. Be careful and upright; small matters can succeed.'],
['Xùn','The Gentle (Wind)','Like wind, advance by gentle persistence. Consult someone wise.'],
['Duì','The Joyous (Lake)','Joyful exchange and study with friends. Be pleasant yet principled.'],
['Huàn','Dispersion','People are scattering. Regather and start again.'],
['Jié','Limitation','Moderation helps, but excessive restraint cannot last.'],
['Zhōng Fú','Inner Truth','Sincerity moves others. Deal honestly.'],
['Xiǎo Guò','Small Exceeding','Small matters are fine, large ones are not. Keep a low profile.'],
['Jì Jì','After Completion','Just completed. Guard against slipping back; avoid good-then-chaos.'],
['Wèi Jì','Before Completion','Not yet done. Discern carefully; hope remains.']
];
const EN_LIU=[['Da An','Great Peace','Smooth','Calm and settled. Favors holding steady and following the plan.'],['Liu Lian','Lingering','Slow','Delays and back-and-forth. Favors patience over pushing ahead.'],
['Su Xi','Swift Joy','Favorable','Good news may come quickly. Favors acting early while it is near.'],['Chi Kou','Red Mouth','Careful','Watch your words; quarrels are likely. Favors speaking less and avoiding conflict.'],
['Xiao Ji','Minor Fortune','Favorable','Harmony and small gains. Favors communication and cooperation.'],['Kong Wang','The Void','Blocked','Efforts tend to come to nothing. Favors pausing and trying another time.']];
const EN_ZHI=['Rat','Ox','Tiger','Rabbit','Dragon','Snake','Horse','Goat','Monkey','Rooster','Dog','Pig'];
const EN_BADGE={吉:'Favorable',缓:'Slow',慎:'Careful',凶:'Blocked'};
const en=()=>LANG==='en';
const gName=i=>en()?`${EN_G[i][0]} · ${EN_G[i][1]}`:G[i][0];
const gFull=i=>{if(!en())return fullName(i);const[,u,l]=G[i];return u===l?`${EN_NAT[u]} doubled`:`${EN_NAT[u]} over ${EN_NAT[l]}`};
const gPlain=i=>en()?EN_G[i][2]:G[i][5];
const lineName=(pos,yang)=>en()?`Line ${pos+1} (${yang?'yang':'yin'})`:yaoName(pos,yang);
const num=n=>en()?String(n):cnNum(n);
const HITLBL={'o-coins':['铜钱：铜钱摇卦','Coins: cast a hexagram'],'o-burner':['香炉：时辰起课','Incense burner: hourly reading'],'o-book':['《周易》古书：卦例解析','Book of Changes: the 64 hexagrams'],'o-paper':['卦纸与毛笔：周毅解卦','Paper and brush: a reading with Zhou Yi'],'o-painting':['山水画：了解小六爻','Landscape painting: about this site']};
const CONTACT=[]; // add entries, e.g. {k:['微信','WeChat'],v:'your_id'} or {k:['邮箱','Email'],u:'name',d:'example.com'}
const REPLY=['','']; // e.g. ['一至三日内回复','Replies within 1–3 days']
function applyLang(){
  const E=en();document.documentElement.lang=E?'en':'zh-CN';document.body.classList.toggle('en',E);
  document.title=T('周毅小六爻 · 铜钱摇卦与小六壬','Zhou Yi Xiao Liu Yao · Coin Divination & Xiao Liu Ren');
  document.querySelectorAll('[data-zh]').forEach(el=>{el.innerHTML=E?el.dataset.en:el.dataset.zh});
  document.querySelectorAll('[data-lbl]').forEach(el=>{const a=HITLBL[el.dataset.lbl];el.setAttribute('aria-label',E?a[1]:a[0])});
  $('#lang').textContent=E?'中文':'EN';$('#lang').setAttribute('aria-label',E?'切换到中文':'Switch to English');
  $('#snd span').textContent=E?'♪':'声';
}

const VIEWS={
  cast(){
    body.innerHTML=`<div class="sec-head"><h2 id="sheet-title">${T('铜钱摇卦','Cast the Coins')}</h2><p class="tag">${T('静心一问 · 一摇一卦','One question · one hexagram')}</p></div>
     <label class="label" for="q">${T('所问之事','Your question')}</label>
     <textarea id="q" rows="3" maxlength="120" placeholder="${T('例如：这次换工作，我该怎样把握时机？','e.g. I am thinking about changing jobs. What should I pay attention to?')}"></textarea>
     <p class="note">${T('一事一问。《周易·蒙》说“初筮告，再三渎”，同一件事不宜反复占问。','One matter, one question. The Book of Changes (Hexagram 4) says the first asking is answered and repeated asking is disrespectful, so please do not re-cast for the same matter.')}</p>
     <div class="actions"><button class="btn-ink" id="begin">${T('开始摇卦','Begin')}</button></div>
     <p class="small-print">${T('铜钱由浏览器的安全随机数抛出，你的提问只保存在你自己的浏览器里。结果仅供传统文化体验与自我观察。','The coins are tossed with your browser’s secure random numbers, and your question stays in your own browser. For cultural experience and self-reflection only.')}</p>`;
    $('#begin').onclick=()=>startCast($('#q').value.trim());
  },
  xlr(){
    body.innerHTML=`<div class="sec-head"><h2 id="sheet-title">${T('小六爻 · 时辰起课','Hourly Reading · Xiao Liu Ren')}</h2><p class="tag">${T('一炷香里 · 依小六壬月日时法','Counted by lunar month, day and double-hour')}</p></div>
     <div class="when"><div><label class="label" for="xt">${T('起课时间','Date and time')}</label><input type="datetime-local" id="xt"></div><button class="btn-line" id="xnow">${T('用此刻','Now')}</button></div>
     <p class="lunar" id="lunar" aria-live="polite"></p>
     <div class="palm" id="palm">${[1,2,3,0,5,4].map(i=>`<div class="cell" data-i="${i}"><span class="marks"></span><b>${en()?EN_LIU[i][0]:LIU[i][0]}</b><small>${en()?EN_LIU[i][1]:LIU[i][1]}</small></div>`).join('')}</div>
     <p class="trail" id="trail"></p>
     <div class="xres" id="xres" aria-live="polite"></div>
     <p class="small-print">${T('六宫依次为大安、留连、速喜、赤口、小吉、空亡。流派不同算法略有出入，本站从大安起，按农历月、日、时辰序数相加计算。','The six palaces are Da An, Liu Lian, Su Xi, Chi Kou, Xiao Ji and Kong Wang. Schools count slightly differently; this site starts at Da An and adds the lunar month, lunar day and double-hour number. For cultural experience and self-reflection only.')}</p>`;
    const xt=$('#xt');const now=()=>{const d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());xt.value=d.toISOString().slice(0,16)};
    now();runXlr();xt.onchange=runXlr;$('#xnow').onclick=()=>{now();runXlr()};
  },
  gua(){
    body.innerHTML=`<div class="sec-head"><h2 id="sheet-title">${T('卦例解析','The 64 Hexagrams')}</h2><p class="tag">${T('六十四卦 · 深入浅出','Classical text with plain-language notes')}</p></div>
     <div class="gua-grid">${G.map((g,i)=>`<button data-gua="${i}" aria-label="${T('第'+(i+1)+'卦 '+g[0],'Hexagram '+(i+1)+': '+EN_G[i][1])}">${fig(TRI[g[2]]+TRI[g[1]],null,'mini')}<span>${en()?EN_G[i][0]:g[0]}</span></button>`).join('')}</div>
     <p class="small-print">${T('按通行本《周易》卦序排列。点开一卦，查看卦辞、象辞与白话。','Listed in the traditional King Wen order. Open one to see the classical judgment and image, with a plain-language note (our own paraphrase).')}</p>`;
    body.querySelectorAll('[data-gua]').forEach(b=>b.onclick=()=>guaDetail(+b.dataset.gua));
  },
  about(){
    body.innerHTML=en()?`<div class="sec-head"><h2 id="sheet-title">About Xiao Liu Yao</h2><p class="tag">One question · one hexagram</p></div>
     <div class="prose">
      <p>Xiao Liu Yao is a small study for experiencing classical Chinese divination. Everything on the desk can be opened: the coins cast a hexagram, the incense burner counts an hourly reading, the old Book of Changes lets you browse all 64 hexagrams, and the brush and paper lead to a one-to-one reading with Zhou Yi. Hexagram texts come from the Book of Changes (Zhou Yi) and its Image commentary; the plain-language notes are our own paraphrase.</p>
      <h3>How the coin method works</h3>
      <p>Three coins are tossed together. The inscribed side counts 2 and the plain back counts 3, and the total is 6, 7, 8 or 9. Seven is young yang and eight is young yin. Nine is old yang (○) and six is old yin (×). Old lines are moving lines and change into their opposite.</p>
      <p>Six tosses, from the bottom up, build the primary hexagram. Changing the moving lines gives the resulting hexagram. Read the first as the present and the second as the direction of travel. When you close the page, the hexagram is written on the paper on the desk.</p>
      <h3>How the hourly method works</h3>
      <p>Start at Da An and count to the lunar month, then count on by the lunar day, and finally by the double-hour. The palace you land on is the result.</p>
      <h3>Please note</h3>
      <p>This site is offered for cultural experience and personal reflection. It does not predict health, legal, financial or investment outcomes and is not advice of any kind. For important decisions, please consult a qualified professional.</p>
     </div>
     <div class="actions"><button class="btn-ink" data-open="cast">Cast the coins</button><button class="btn-line" data-open="xlr">Hourly reading</button></div>`
    :`<div class="sec-head"><h2 id="sheet-title">了解小六爻</h2><p class="tag">一卦一问 · 观己省身</p></div>
     <div class="prose">
      <p>小六爻是一间体验传统术数的书房。案上的东西都能点：铜钱用来摇卦，香炉按时辰起课，《周易》古书里查六十四卦，卦纸与毛笔用来请周毅解卦。卦义取自《周易》经文与《象传》，白话为本站概括。</p>
      <h3>铜钱摇卦怎么算</h3>
      <p>三枚铜钱同时抛下，有字一面记二，无字的背面记三，三枚相加得六、七、八、九。七为少阳，八为少阴；九为老阳，记作 ○；六为老阴，记作 ×。老阳、老阴是动爻，会变成相反的爻。</p>
      <p>自下而上摇六次，得到本卦；动爻变过之后得到变卦。本卦看眼下，变卦看走向。摇完之后，案上的卦纸会写上你这一卦。</p>
      <h3>时辰起课怎么算</h3>
      <p>从大安起，先数到农历月，再从那里数农历日，最后数时辰，落在哪一宫就是结果。六宫依次为大安、留连、速喜、赤口、小吉、空亡。</p>
      <h3>使用说明</h3>
      <p>本站内容用于传统文化体验与自我观察，不预测健康、法律、投资等结果，也不构成任何决策建议。遇到重要决定，请咨询相应的专业人士。</p>
     </div>
     <div class="actions"><button class="btn-ink" data-open="cast">开始摇卦</button><button class="btn-line" data-open="xlr">时辰起课</button></div>`;
  },
  contact(){
    let l='';
    if(LAST&&LAST.a!=null){const mv=LAST.moving.map(i=>lineName(i,LAST.bits[i]==='1')).join(en()?', ':'、');
      l=en()?`Primary: ${gName(LAST.a)} (${gFull(LAST.a)})${LAST.moving.length?`; moving: ${mv}; resulting: ${gName(LAST.b)}`:'; no moving lines'}${LAST.q?`. Question: ${LAST.q}`:''}`
        :`本卦${G[LAST.a][0]}（${fullName(LAST.a)}）${LAST.moving.length?`，${mv}动，变卦${G[LAST.b][0]}`:'，六爻皆静'}${LAST.q?`。所问：${LAST.q}`:''}`}
    const rows=CONTACT.map(c=>{const v=c.u?`${c.u}@${c.d}`:c.v;return `<div class="contact-row"><span>${T(c.k[0],c.k[1])}</span><span class="sel">${c.u?`<a href="mailto:${esc(v)}">${esc(v)}</a>`:esc(v)}</span></div>`}).join('')
      +(REPLY[0]?`<div class="contact-row"><span>${T('答复时间','Reply time')}</span><span>${T(REPLY[0],REPLY[1])}</span></div>`:'');
    body.innerHTML=`<div class="sec-head"><h2 id="sheet-title">${T('周毅解卦','A Reading with Zhou Yi')}</h2><p class="tag">${T('一对一 · 细致解读','One-to-one · thoughtful interpretation')}</p></div>
     <div class="prose">
      ${l?`<p class="note" style="margin:0 0 6px">${T('你最近起的一卦，联系时可直接附上：','Your latest hexagram. Include this when you get in touch:')}</p><div class="last"><span id="lastline">${esc(l)}</span><button class="btn-line" id="copy" style="height:36px">${T('复制','Copy')}</button></div>`
        :`<p>${T('先用铜钱摇一卦，卦纸上会写下卦象，再带着卦名来问会更清楚。','Cast a hexagram first. It is written on the paper, and bringing the hexagram name makes the conversation clearer.')}</p>`}
      <p>${T('需要一对一解卦，可通过下面的方式联系周毅，说明所问之事与卦名即可。','For a one-to-one reading, contact Zhou Yi with your question and the hexagram name.')}</p>
      ${rows||`<p class="note">${T('联系方式即将开放。','Contact details are coming soon.')}</p>`}
      <p class="small-print">${T('解卦为传统文化交流，不提供医疗、法律、投资方面的建议。','A reading is a cultural conversation. It does not include medical, legal or financial advice.')}</p>
     </div>
     <div class="actions"><button class="btn-ink" data-open="cast">${l?T('再摇一卦','Cast again'):T('先摇一卦','Cast a hexagram')}</button></div>`;
    const c=$('#copy');if(c)c.onclick=()=>{const t=$('#lastline').textContent;
      navigator.clipboard.writeText(t).then(()=>{c.textContent=T('已复制','Copied')},()=>{const r=document.createRange();r.selectNodeContents($('#lastline'));const s=getSelection();s.removeAllRanges();s.addRange(r);c.textContent=T('已选中','Selected')})};
  }
};

/* ---------- casting flow ---------- */
let C;
function startCast(q){
  C={q,vals:[],busy:false,cur:[0,0,0]};
  body.innerHTML=`<div class="sec-head"><h2 id="sheet-title">${T('铜钱摇卦','Cast the Coins')}</h2><p class="tag">${T('自下而上 · 六摇成卦','Six tosses, from the bottom up')}</p></div>
   <div class="cast">
     <div>
       <p class="asked">${T('所问：','Your question: ')}<b>${q?esc(q):T('（心中默念）','(held in mind)')}</b></p>
       <div class="coins">${[0,1,2].map(()=>`<div class="coin-w"><div class="coin">${coinSVG(false)}${coinSVG(true)}</div></div>`).join('')}</div>
       <p class="progress" id="prog" aria-live="polite">${T('静心片刻，摇第一爻','Settle your mind, then toss the first line')}</p>
       <div class="actions"><button class="btn-ink" id="toss">${T('摇第一爻','Toss line 1')}</button></div>
       <ol class="log" id="log"></ol>
     </div>
     <div class="fig-col"><div class="fig grow" id="grow"></div><p>${T('卦自下而上','Built from the bottom')}</p></div>
   </div>`;
  $('#toss').onclick=toss;
}
const POS=()=>en()?['Line 1','Line 2','Line 3','Line 4','Line 5','Line 6']:['初爻','二爻','三爻','四爻','五爻','上爻'];
const KIND=v=>en()?{6:'old yin ×',7:'young yang',8:'young yin',9:'old yang ○'}[v]:{6:'老阴 ×',7:'少阳',8:'少阴',9:'老阳 ○'}[v];
async function toss(){
  if(C.busy)return;
  if(C.vals.length===6){showResult();return}
  C.busy=true;const btn=$('#toss');btn.disabled=true;
  const faces=[rnd(),rnd(),rnd()]; // 1 = 背 (3), 0 = 字 (2)
  const coins=[...body.querySelectorAll('.coin')];
  AU.toss(coins.map((_,i)=>reduce?120:950+i*150));
  await Promise.all(coins.map((el,i)=>{
    const from=C.cur[i],to=from-(from%360)+360*(3+Math.floor(Math.random()*3))+(faces[i]?180:0);C.cur[i]=to;
    const tilt=(Math.random()*24-12).toFixed(1),d=reduce?120:950+i*150;
    return el.animate([{transform:`translateY(0) rotateX(${from}deg)`},{transform:`translateY(-96px) rotateX(${(from+to)/2}deg) rotateZ(${tilt}deg)`,offset:.45},
      {transform:`translateY(0) rotateX(${to}deg) rotateZ(0deg)`}],{duration:d,easing:'cubic-bezier(.33,.62,.4,1)',fill:'forwards'}).finished;
  }));
  const backs=faces.reduce((a,b)=>a+b,0),v=6+backs;C.vals.push(v);
  const n=C.vals.length;
  const face=en()?['three inscribed','two inscribed, one plain','one inscribed, two plain','three plain'][backs]:['三字','一背两字','两背一字','三背'][backs];
  $('#log').insertAdjacentHTML('afterbegin',`<li><b>${POS()[n-1]}</b><span>${face}</span><span>${KIND(v)}</span></li>`);
  const yang=v===7||v===9,mv=v===9?'○':v===6?'×':'';
  $('#grow').insertAdjacentHTML('beforeend',`<div class="yao new"${mv?` data-mv="${mv}"`:''}><i></i>${yang?'':'<i></i>'}</div>`);
  $('#prog').textContent=n<6?T(`已成${cnNum(n)}爻，再摇第${cnNum(n+1)}爻`,`Line ${n} done. Toss line ${n+1}.`):T('六爻已成','All six lines are cast');
  btn.textContent=n<6?T(`摇第${cnNum(n+1)}爻`,`Toss line ${n+1}`):T('观卦象','Reveal the hexagram');
  btn.disabled=false;C.busy=false;
}
function showResult(){
  const v=C.vals,bits=v.map(x=>x===7||x===9?'1':'0').join(''),chg=v.map(x=>x===9?'0':x===6?'1':(x===7?'1':'0')).join('');
  const a=BY_BITS[bits],b=BY_BITS[chg],moving=v.map((x,i)=>x===6||x===9?i:-1).filter(i=>i>=0);
  LAST={bits,vals:v,a,b,moving,q:C.q};store.set('xly-last',LAST);pendingInk=true;AU.gong();
  const block=(i,label)=>`<h3>${label} · ${T('第'+cnNum(i+1)+'卦','Hexagram '+(i+1))} ${gName(i)} <small>${gFull(i)}</small></h3>
     <p><span class="k">${T('卦辞','Judgment')}</span><span lang="zh">${G[i][3]}</span></p><p><span class="k">${T('象曰','Image')}</span><span lang="zh">${G[i][4]}</span></p><p class="plain">${en()?'<b>In plain words:</b> ':''}${gPlain(i)}</p>`;
  const cap=(s,i)=>`<figcaption><small>${s}</small>${en()?EN_G[i][1]:G[i][0]}</figcaption>`;
  body.innerHTML=`<div class="sec-head"><span class="chop" aria-hidden="true">卦</span><h2 id="sheet-title">${T('卦成','Your Hexagram')}</h2><p class="tag">${C.q?T('所问：','Question: ')+esc(C.q):T('心中所问','Your question, held in mind')}</p></div>
   <div class="result-figs">
     <figure>${fig(bits,v)}${cap(T('本卦','Primary'),a)}</figure>
     ${moving.length?`<span class="to" aria-hidden="true">→</span><figure>${fig(chg)}${cap(T('变卦','Resulting'),b)}</figure>`:''}
   </div>
   <p class="lines">${[5,4,3,2,1,0].map(i=>`<span class="${moving.includes(i)?'mv':''}">${lineName(i,bits[i]==='1')}${moving.includes(i)?(v[i]===9?' ○':' ×'):''}</span>`).join('')}</p>
   <hr class="rule">
   <div class="reading">
     ${block(a,T('本卦','Primary'))}
     ${moving.length?`<p class="note" style="margin-top:14px">${T('动爻：','Moving lines: ')}${moving.map(i=>lineName(i,bits[i]==='1')).join(en()?', ':'、')}${T('。本卦看眼下，变卦看走向。','. Read the primary hexagram as the present and the resulting one as the direction.')}</p><hr class="rule">${block(b,T('变卦','Resulting'))}`
       :`<p class="note" style="margin-top:14px">${T('六爻皆静，以本卦卦辞为主。','No moving lines, so the primary hexagram’s judgment stands on its own.')}</p>`}
   </div>
   <p class="small-print" style="margin-top:22px">${T('合上这页，案上的卦纸会写下这一卦。','Close this page and the hexagram is written on the paper on the desk.')}</p>
   <div class="actions"><button class="btn-ink" data-open="cast">${T('再起一卦','Cast again')}</button><button class="btn-line" data-open="contact">${T('请周毅解卦','Ask Zhou Yi')}</button></div>
   <p class="small-print">${T('仅供传统文化体验与自我观察，不构成任何决策建议。','For cultural experience and self-reflection only. Not advice of any kind.')}</p>`;
  sheet.scrollTop=0;
}

/* ---------- 64 hexagram detail ---------- */
function guaDetail(i){
  const g=G[i];
  body.innerHTML=`<button class="back" id="back">${T('← 返回六十四卦','← Back to all 64')}</button>
   <div class="detail">${fig(TRI[g[2]]+TRI[g[1]])}
    <div class="reading"><h3 id="sheet-title">${T('第'+cnNum(i+1)+'卦','Hexagram '+(i+1))} ${gName(i)} <small>${gFull(i)}</small></h3>
     <p class="note" style="margin:0 0 10px">${en()?`Upper trigram: ${EN_NAT[g[1]]} · Lower trigram: ${EN_NAT[g[2]]}`:`上卦 ${g[1]}（${NAT[g[1]]}） · 下卦 ${g[2]}（${NAT[g[2]]}）`}</p>
     <p><span class="k">${T('卦辞','Judgment')}</span><span lang="zh">${g[3]}</span></p><p><span class="k">${T('象曰','Image')}</span><span lang="zh">${g[4]}</span></p><p class="plain">${en()?'<b>In plain words:</b> ':''}${gPlain(i)}</p></div></div>
   <div class="actions"><button class="btn-ink" data-open="cast">${T('摇一卦','Cast a hexagram')}</button></div>`;
  $('#back').onclick=()=>VIEWS.gua();sheet.scrollTop=0;
}

'''
a = s.index('const VIEWS={')
b = s.index('/* ---------- 小六壬 ---------- */')
s = s[:a] + JS_NEW.lstrip('\n') + s[b:]

# ---------- xlr run ----------
a = s.index('/* ---------- 小六壬 ---------- */')
b = s.index("const snd=$('#snd')")
XLR = r'''/* ---------- 小六壬 ---------- */
let xlrTimers=[];
function runXlr(){
  xlrTimers.forEach(clearTimeout);xlrTimers=[];
  const val=$('#xt').value;const d=val?new Date(val):new Date();
  const p=Object.fromEntries(new Intl.DateTimeFormat('en-u-ca-chinese',{month:'numeric',day:'numeric'}).formatToParts(d).map(x=>[x.type,x.value]));
  const zh=Object.fromEntries(new Intl.DateTimeFormat('zh-CN-u-ca-chinese',{month:'long'}).formatToParts(d).map(x=>[x.type,x.value]));
  const m=parseInt(p.month,10),day=parseInt(p.day,10),zi=Math.floor((d.getHours()+1)/2)%12,h=zi+1;
  const dayCN=day<=10?'初'+NUM[day-1]:day<20?'十'+NUM[day-11]:day===20?'二十':day<30?'廿'+NUM[day-21]:'三十';
  $('#lunar').textContent=T(`农历${zh.month||cnNum(m)+'月'}${dayCN} · ${ZHI[zi]}时`,`Lunar month ${m}, day ${day} · Hour of the ${EN_ZHI[zi]}`);
  const steps=[(m-1)%6,(m+day-2)%6,(m+day+h-3)%6],tags=T(['月','日','时'],['M','D','H']);
  const nm=i=>en()?EN_LIU[i][0]:LIU[i][0];
  const cells=[...document.querySelectorAll('#palm .cell')];
  cells.forEach(c=>{c.classList.remove('final');c.querySelector('.marks').innerHTML=''});
  $('#xres').innerHTML='';$('#trail').textContent='';
  steps.forEach((s,k)=>xlrTimers.push(setTimeout(()=>{
    AU.tap();const c=cells.find(c=>+c.dataset.i===s);c.querySelector('.marks').insertAdjacentHTML('beforeend',`<i>${tags[k]}</i>`);
    if(k===2){c.classList.add('final');const r=LIU[s];AU.chime(r[1]==='吉');
      $('#trail').textContent=T(`月（${cnNum(m)}）落${LIU[steps[0]][0]}，日（${day}）落${LIU[steps[1]][0]}，时（${ZHI[zi]}，第${h}）落${r[0]}`,`Month (${m}) lands on ${nm(steps[0])}, day (${day}) on ${nm(steps[1])}, hour (${EN_ZHI[zi]}, no. ${h}) on ${nm(s)}`);
      $('#xres').innerHTML=en()?`<h3>${EN_LIU[s][0]} · ${EN_LIU[s][1]}<span class="badge">${EN_LIU[s][2]}</span></h3><p>${EN_LIU[s][3]}</p>`:`<h3>${r[0]}<span class="badge">${r[1]}</span></h3><p>${r[2]}</p>`}
  },reduce?0:300+k*600)));
}

'''
s = s[:a] + XLR + s[b:]

# ---------- tail: language, dust ----------
rep("snd.onclick=()=>{AU.toggle();syncSnd()};syncSnd();", r'''snd.onclick=()=>{AU.toggle();syncSnd()};syncSnd();
LANG=store.get('xly-lang')||((navigator.language||'').toLowerCase().startsWith('zh')?'zh':'en');
$('#lang').onclick=()=>{LANG=en()?'zh':'en';store.set('xly-lang',LANG);if(sheet.open)sheet.close();applyLang();AU.tick()};
applyLang();
/* drifting dust in the lamplight */
const dc=$('#dust'),dx=dc.getContext('2d');let motes=[];
function sizeDust(){const r=dc.getBoundingClientRect();dc.width=Math.max(1,r.width/2|0);dc.height=Math.max(1,r.height/2|0);
  motes=Array.from({length:38},()=>({x:Math.random(),y:Math.random(),r:.5+Math.random()*1.1,vx:(Math.random()-.5)*.00005,vy:-.00002-Math.random()*.00004,ph:Math.random()*6.28,sp:.4+Math.random()})) }
function dust(t){
  requestAnimationFrame(dust);if(document.hidden||sheet.open)return;
  const w=dc.width,h=dc.height;dx.clearRect(0,0,w,h);dx.globalCompositeOperation='lighter';
  for(const m of motes){
    m.x+=m.vx*16+Math.sin(t*.0003*m.sp+m.ph)*.00007;m.y+=m.vy*16;
    if(m.y<-.02){m.y=1.02;m.x=Math.random()}if(m.x<0)m.x=1;if(m.x>1)m.x=0;
    const a=(.22+.22*Math.sin(t*.001*m.sp+m.ph))*(.35+(1-m.y)*.65);
    dx.beginPath();dx.fillStyle=`rgba(255,222,165,${a.toFixed(3)})`;dx.arc(m.x*w,m.y*h,m.r,0,6.283);dx.fill();
  }
}''')
rep("placeInk();sizeSmoke();", "placeInk();sizeSmoke();sizeDust();")
rep("if(!reduce)requestAnimationFrame(smoke);", "if(!reduce){requestAnimationFrame(smoke);requestAnimationFrame(dust)}")
open('src3.html', 'w', encoding='utf-8').write(s)
print('ok', len(s))
