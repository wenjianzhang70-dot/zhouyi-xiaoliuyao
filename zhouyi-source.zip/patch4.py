s = open('src3.html', encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:70], s.count(old))
    s = s.replace(old, new)

rep('&family=EB+Garamond', '&family=Zhi+Mang+Xing&family=EB+Garamond')
rep("  --btn:url(__BTN__);", "  --btn:url(__BTN__);\n  --f-jh:'Zhi Mang Xing','Ma Shan Zheng','STXingkai','KaiTi',serif;")

# ---- coin css ----
rep('''.coin-w{position:relative;width:clamp(64px,13vw,86px);aspect-ratio:1}
.coin-w::after{content:"";position:absolute;left:12%;right:12%;bottom:-9%;height:14%;border-radius:50%;background:radial-gradient(rgba(30,20,8,.45),transparent 70%);z-index:-1}
.coin{position:absolute;inset:0;transform-style:preserve-3d}
.coin svg{position:absolute;inset:0;width:100%;height:100%;backface-visibility:hidden;-webkit-backface-visibility:hidden;filter:drop-shadow(0 2px 2px rgba(30,18,6,.35))}
.coin svg.back{transform:rotateX(180deg)}''', '''.coin-w{position:relative;width:clamp(78px,19vw,112px);aspect-ratio:1}
.shadow{position:absolute;left:8%;right:8%;bottom:-11%;height:18%;border-radius:50%;background:radial-gradient(rgba(28,18,6,.55),transparent 70%)}
.coin{position:absolute;inset:0;transform-style:preserve-3d}
.coin img{position:absolute;inset:0;width:100%;height:100%;user-select:none;-webkit-user-drag:none}
.coin .front{transform:translateZ(3px);backface-visibility:hidden;-webkit-backface-visibility:hidden}
.coin .back{transform:rotateX(180deg) translateZ(3px);backface-visibility:hidden;-webkit-backface-visibility:hidden}
.coin .edge{filter:brightness(.42) sepia(.5)}
.shine{position:absolute;inset:0;pointer-events:none;-webkit-mask:var(--coin-mask) center/100% no-repeat;mask:var(--coin-mask) center/100% no-repeat;
  background:linear-gradient(115deg,transparent 38%,rgba(255,236,190,.75) 50%,transparent 62%) 160% 0/260% 100% no-repeat;opacity:0;mix-blend-mode:screen}
.shine.go{animation:sweep .9s ease-out}
@keyframes sweep{0%{opacity:1;background-position:160% 0}100%{opacity:1;background-position:-60% 0}}
.puff{position:absolute;left:-20%;right:-20%;bottom:-24%;height:46%;border-radius:50%;pointer-events:none;
  background:radial-gradient(closest-side,rgba(120,96,64,.38),rgba(120,96,64,0));animation:puff .7s ease-out forwards}
@keyframes puff{from{transform:scale(.3);opacity:1}to{transform:scale(1.25,1);opacity:0}}
.yao.new[data-mv] i{animation:brush .5s cubic-bezier(.3,.7,.3,1) both,mvglow 1.8s .5s ease-out}
@keyframes mvglow{30%{box-shadow:0 0 12px 2px rgba(155,45,29,.75);background:var(--cinnabar)}}
.result-figs .fig{animation:inkin 1s cubic-bezier(.2,.7,.2,1) both}
.result-figs figure+.to+figure .fig{animation-delay:.35s}
@keyframes inkin{from{opacity:0;filter:blur(6px);transform:scale(1.06)}}''')

# ---- jianghu brush type inside the sheet (Chinese only; body copy stays serif for legibility) ----
rep('</style>', '''
body:not(.en) .sec-head h2{font:400 clamp(34px,5.6vw,44px)/1.15 var(--f-jh);letter-spacing:.08em}
body:not(.en) :is(.btn-ink,.progress,.log li b,.result-figs figcaption,.reading h3,.xres h3,.cell b,.label,.back){font-family:var(--f-jh);font-weight:400}
body:not(.en) .btn-ink{font-size:21px}
body:not(.en) .reading h3{font-size:24px}
body:not(.en) .result-figs figcaption{font-size:22px}
body:not(.en) .progress{font-size:19px}
body:not(.en) .cell b{font-size:24px}
body:not(.en) .label{font-size:17px}
</style>''')

# ---- coin markup ----
a = s.index('function coinSVG(back){'); b = s.index('\n}\n', a) + 3
s = s[:a] + '''function coinHTML(){
  let e='';for(let k=0;k<5;k++)e+=`<img class="edge" src="${COIN_B}" alt="" style="transform:translateZ(${(k-2)*1.3}px)">`;
  return `<img class="front" src="${COIN_F}" alt="">${e}<img class="back" src="${COIN_B}" alt="">`;
}
const COIN_F='__COIN_F__',COIN_B='__COIN_B__';
document.documentElement.style.setProperty('--coin-mask',`url(${COIN_B})`);
''' + s[b:]
rep('<div class="coin-w"><div class="coin">${coinSVG(false)}${coinSVG(true)}</div></div>', '<div class="coin-w"><div class="shadow"></div><div class="coin">${coinHTML()}</div><div class="shine"></div></div>')

# ---- toss with bounce, shadow, dust, shake, glint ----
rep('''  AU.toss(coins.map((_,i)=>reduce?120:950+i*150));
  await Promise.all(coins.map((el,i)=>{
    const from=C.cur[i],to=from-(from%360)+360*(3+Math.floor(Math.random()*3))+(faces[i]?180:0);C.cur[i]=to;
    const tilt=(Math.random()*24-12).toFixed(1),d=reduce?120:950+i*150;
    return el.animate([{transform:`translateY(0) rotateX(${from}deg)`},{transform:`translateY(-96px) rotateX(${(from+to)/2}deg) rotateZ(${tilt}deg)`,offset:.45},
      {transform:`translateY(0) rotateX(${to}deg) rotateZ(0deg)`}],{duration:d,easing:'cubic-bezier(.33,.62,.4,1)',fill:'forwards'}).finished;
  }));''', '''  const D=coins.map((_,i)=>reduce?120:1050+i*170);
  AU.toss(D.map(d=>d*.78));
  await Promise.all(coins.map((el,i)=>{
    const from=C.cur[i],to=from-(from%360)+360*(3+Math.floor(Math.random()*3))+(faces[i]?180:0);C.cur[i]=to;
    const tilt=(Math.random()*30-15).toFixed(1),d=D[i],h=-(95+Math.random()*30),w=el.parentNode;
    if(reduce)return el.animate([{transform:`rotateX(${to}deg)`}],{duration:d,fill:'forwards'}).finished;
    w.querySelector('.shadow').animate([{transform:'scale(1)',opacity:1},{transform:'scale(.42)',opacity:.3,offset:.4},{transform:'scale(1)',opacity:1,offset:.78},{transform:'scale(.85)',opacity:.8,offset:.88},{transform:'scale(1)',opacity:1}],{duration:d});
    setTimeout(()=>{w.insertAdjacentHTML('beforeend','<i class="puff"></i>');setTimeout(()=>{const p=w.querySelector('.puff');p&&p.remove()},800);
      body.querySelector('.coins').animate([{transform:'none'},{transform:'translate(1.5px,1px)'},{transform:'translate(-1px,-.5px)'},{transform:'none'}],{duration:160})},d*.78);
    return el.animate([
      {transform:`translateY(0) rotateX(${from}deg) rotateZ(0deg)`,easing:'cubic-bezier(.2,.65,.4,1)'},
      {transform:`translateY(${h}px) rotateX(${(from+to)/2}deg) rotateZ(${tilt}deg)`,offset:.4,easing:'cubic-bezier(.55,0,.85,.45)'},
      {transform:`translateY(0) rotateX(${to+10}deg) rotateZ(0deg)`,offset:.78,easing:'ease-out'},
      {transform:`translateY(-10px) rotateX(${to-4}deg) rotateZ(0deg)`,offset:.88,easing:'ease-in'},
      {transform:`translateY(0) rotateX(${to}deg) rotateZ(0deg)`}],{duration:d,fill:'forwards'}).finished;
  }));
  if(!reduce)body.querySelectorAll('.shine').forEach((x,i)=>{x.classList.remove('go');void x.offsetWidth;setTimeout(()=>x.classList.add('go'),i*90)});''')
import re
a=s.index('    <radialGradient id="bronze"');b=s.index('</mask>',a)+len('</mask>')
s=s[:a]+s[b:].lstrip(' ').lstrip('\n')
open('src4.html', 'w', encoding='utf-8').write(s)
print('ok')
