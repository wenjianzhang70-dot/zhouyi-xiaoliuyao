import base64, json
s = open('src5.html', encoding='utf-8').read()
old = open('src.html', encoding='utf-8').read()
data = old[old.index('/* ---------- data ---------- */'):old.index('/* ---------- small helpers ---------- */')]
s = s.replace('/*__DATA__*/', data)
uri = lambda f, t: f'data:{t};base64,' + base64.b64encode(open(f, 'rb').read()).decode()
s = s.replace('__PLATE__', uri('work/scene_plate.jpg', 'image/jpeg'))
s = s.replace('__COIN_F__', uri('work/coin_front.webp', 'image/webp')).replace('__COIN_B__', uri('work/coin_back.webp', 'image/webp'))
s = s.replace('__CARD__', uri('work/card.jpg', 'image/jpeg')).replace('__BTN__', uri('work/btn.webp', 'image/webp'))
g = json.load(open('work/scene_geo.json'))
for n, o in g['objects'].items():
    x, y, w, h = o['box']
    s = s.replace(f'__BOX_{n}__', f'left:{x}%;top:{y}%;width:{w}%;height:{h}%')
    t = o['poly'].split()
    s = s.replace(f'__POLY_{n}__', ','.join(f'{a} {b}' for a, b in zip(t[0::2], t[1::2])))
    s = s.replace(f'__SP_{n}__', uri(f'work/sp_{n}.webp', 'image/webp'))
x, y, w, h = g['objects']['paper']['box']
s = s.replace('__PAPER_BOX__', ','.join(str(round(v)) for v in (x * 12.06, y * 8.04, w * 12.06, h * 8.04)))
assert '__' not in s.replace('__proto__', ''), [m for m in s.split() if '__' in m][:5]
open('zhouyi-xiaoliuyao.html', 'w', encoding='utf-8').write(s)
print(len(s) // 1024, 'KB')
