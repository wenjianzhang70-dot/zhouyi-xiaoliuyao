s = open('src4.html', encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:70], s.count(old))
    s = s.replace(old, new)

# ---- fade in / fade out ----
rep("sheet.animate([{transform:'scale(.1)',opacity:0},{transform:'scale(1)',opacity:1}],{duration:440,easing:'cubic-bezier(.2,.75,.2,1)'});",
    "sheet.animate([{transform:'scale(.55)',opacity:0,filter:'blur(6px) drop-shadow(0 26px 50px rgba(0,0,0,.6))'},{transform:'scale(1)',opacity:1,filter:'blur(0) drop-shadow(0 26px 50px rgba(0,0,0,.6))'}],{duration:620,easing:'cubic-bezier(.2,.7,.2,1)'});")
rep("$('#close').onclick=()=>sheet.close();", '''function shut(){
  if(!sheet.open||sheet.classList.contains('closing'))return;
  if(reduce){sheet.close();return}
  sheet.classList.add('closing');
  sheet.animate([{opacity:1,transform:'scale(1)'},{opacity:0,transform:'scale(.94) translateY(12px)'}],{duration:380,easing:'cubic-bezier(.4,0,.7,.2)'}).onfinish=()=>{sheet.close();sheet.classList.remove('closing')};
}
sheet.addEventListener('cancel',e=>{e.preventDefault();shut()});
$('#close').onclick=shut;
/* every view that replaces the sheet's content fades in, block by block */
new MutationObserver(()=>{if(reduce)return;[...body.children].forEach((el,i)=>el.animate([{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'none'}],{duration:520,delay:Math.min(i,8)*70,easing:'cubic-bezier(.2,.7,.2,1)',fill:'backwards'}))}).observe(body,{childList:true});''')
rep("e.clientY>r.bottom)sheet.close()}});", "e.clientY>r.bottom)shut()}});")
rep("if(sheet.open)sheet.close();scene.scrollTo", "shut();scene.scrollTo")
rep("if(sheet.open)sheet.close();applyLang();", "shut();applyLang();")

# ---- larger type ----
rep('</style>', '''
dialog.sheet{width:min(880px,calc(100vw - 20px))}
dialog.sheet[open]::backdrop{animation:fadein .5s ease-out}
dialog.sheet.closing::backdrop{animation:fadeout .38s ease-in forwards}
@keyframes fadeout{to{opacity:0}}
.sheet p,.sheet li{font-size:18px}
.sheet h3{font-size:22px}.sheet h3 small{font-size:16px}
.sec-head .tag{font-size:17px}
.label{font-size:16px}
.note{font-size:16px!important}
.small-print{font-size:14.5px!important}
textarea,input[type=datetime-local]{font-size:18px}
.btn-ink{font-size:19px;height:52px}.btn-line{font-size:17px;height:48px}
.progress{font-size:18px}.log li{font-size:16px!important}
.lines{font-size:16px}.result-figs figcaption{font-size:18px}.result-figs figcaption small{font-size:14px}
.trail{font-size:16px!important}.cell b{font-size:22px}.cell small{font-size:14px}
.gua-grid span{font-size:16px}.back{font-size:16px}
.slip{width:2.2cqw;font-size:1.32cqw}
.inscribe{font-size:1.5cqw}
.hero-sub{font-size:min(1.9cqw,calc(var(--vw,9999px)*.04))}
.brand-text small{font-size:max(11px,1.05vw)}
body.en .sheet p,body.en .sheet li{font-size:19.5px}
body.en .note{font-size:17px!important}body.en .small-print{font-size:15.5px!important}
body.en .sec-head .tag,body.en .label{font-size:18px}
body.en .slip{font-size:1.36cqw}
body.en .inscribe{font-size:1.5cqw}
body:not(.en) .btn-ink{font-size:23px}
body:not(.en) .reading h3{font-size:27px}
body:not(.en) .progress{font-size:22px}
@media (max-width:640px){.sheet p,.sheet li{font-size:17px}body.en .sheet p,body.en .sheet li{font-size:18px}}
</style>''')
open('src5.html', 'w', encoding='utf-8').write(s)
print('ok')
